window.onload = function () {
	var $button = document.getElementById('js-add-blin');
	var $input = document.getElementById('js-mass-blin');
	var $list = document.getElementById('js-list-blin');
	var $massError = document.getElementById('js-mass-error');
	var $leftList = document.getElementById('js-left-list-blin');
	var $rightList = document.getElementById('js-right-list-blin');
	var $equalMess = document.getElementById('js-ready');

	
	var $leftSumm = 0;
	var $rightSumm = 0;
	var $listSumm = 0;
	var $maxListSumm = 10000;
	var $listCount = 0;
	var $maxListCount = 1000;
	$equalMess.innerHTML = 'Штанга пуста!';

	function isEqual(leftSumm, rightSumm) {
		console.log('левая сумма ' + leftSumm);
		console.log('правая сумма ' + rightSumm);
		if((leftSumm == rightSumm) && (leftSumm != 0)) {
			$equalMess.innerHTML = 'Штанга готова! [ ' + leftSumm + ' , ' + rightSumm + ' ]';
		} else if((leftSumm == 0) && (rightSumm == 0)) {
			$equalMess.innerHTML = 'Штанга пуста!';
		} else {
			$equalMess.innerHTML = 'Штанга не равновесна! [ ' + leftSumm + ' , ' + rightSumm + ' ]';
		}
	}


	window.oncontextmenu = function () {
		return false;     
	};



	$leftList.onmousedown = function(e){
		if(e.which == 1) {
			var $target = e.target;
			if ($target.tagName != 'SPAN') return;
			$target.onmouseup = function(e) {
				var $itemVal = $target.innerHTML;
				var $item = document.createElement('span');
				$item.className = "item-blin";
				$item.innerHTML = $itemVal;
				$leftSumm -= Number($itemVal);
				$list.appendChild($item);

				isEqual($leftSumm, $rightSumm);
				$target.remove();
			};
		}

	};


	$rightList.onmousedown = function(e){
		if(e.which == 1) {
			var $target = e.target;
			if ($target.tagName != 'SPAN') return;
			$target.onmouseup = function(e) {
				var $itemVal = $target.innerHTML;
				var $item = document.createElement('span');
				$item.className = "item-blin";
				$item.innerHTML = $itemVal;
				$rightSumm -= Number($itemVal);
				$list.appendChild($item);

				isEqual($leftSumm, $rightSumm);
				$target.remove();
			};
		}

	};


	$list.onmousedown = function(e) {
		var $target = e.target;
		if ($target.tagName != 'SPAN') return;

		$target.onmouseup = function(e) {
			var $itemVal = $target.innerHTML;

			if(e.which == 1) {
				var $leftItem = document.createElement('span');
				$leftItem.className = "item-blin";
				$leftItem.innerHTML = $itemVal;
				$leftSumm += Number($itemVal);
				$leftList.appendChild($leftItem);
			} 

			if(e.which == 3) {
				var $rightItem = document.createElement('span');
				$rightItem.className = "item-blin";
				$rightItem.innerHTML = $itemVal;
				$rightSumm += Number($itemVal);
				$rightList.appendChild($rightItem);
			} 

			isEqual($leftSumm, $rightSumm);
			$target.remove();
		};
	};


	$button.onclick = function() {
		var $blin = Number($input.value);
		var $ostatok = $maxListSumm - $listSumm;
		if ($listCount < $maxListCount) {
			if ($blin <= $ostatok) {
				if ($blin <= 0) {
					$massError.innerHTML = 'Масса блина не может быть 0 и меньше!';
				} else if($blin < 21) {
					$massError.innerHTML = '';

					var $item = document.createElement('span');
					$item.className = "item-blin";
					$item.innerHTML = $blin;

					$listSumm += $blin;
					$listCount ++;
					$list.appendChild($item);
					if($listSumm == 10000) {
						$massError.innerHTML = 'Суммарный вес блинов достиг максимума - 10000!';
					}
				} else {
					$massError.innerHTML = 'Масса блина не должна превышать 20!';
					$input.value = 1;
				}
			} else {
				$massError.innerHTML = 'Масса блина не должна превышать ' + $ostatok + '!';
			}
		} else {
			$massError.innerHTML = 'Добавлено максимальное количество блинов!';
		}

	};
};



