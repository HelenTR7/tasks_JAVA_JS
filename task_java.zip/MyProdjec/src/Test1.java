import java.util.ArrayList;
import java.util.Collections;

/**
 * Created by gr on 19.01.2019.
 */
public class Test1 {
    public static void main(String[] args) throws Exception {
      int t[] = {1,2,3,6};
      int c[] = {2,3,14,9,4,5,2,15};
      int b[] = {1,2};

      //  cislo(t);
        cislo(c);
       // cislo(b);
    }
public static void cislo(int[] mas) throws Exception {
        ArrayList<Integer> list = new ArrayList<>();
        int sym=0;
        if(mas.length>1 && mas.length<1000) { // проверки на условие и подсчет макс значения суммы
            for (int t = 0; t < mas.length; t++) {

                if (mas[t] >= 21) {
                    throw new Exception();
                }
                sym += mas[t];
            }
            if (sym > 10000) {
                throw new Exception();
            }
        }
        else throw new Exception();



        for(int t=0; t<mas.length; t++) {  // перевод в list массив
            list.add(mas[t]);
        }
        Collections.sort(list);
        Collections.reverse(list);
        sym/=2;
        for(int m=0; m<10000; m++) {
            int symm=sym-m;
            ras2(symm, list);
            if(ras2(symm,list)==false){
                break;
            }
        }

}

public static boolean  ras2(int sym, ArrayList<Integer> list) {
        ArrayList<Integer> list1 = new ArrayList<>();
        ArrayList<Integer> list2 = new ArrayList<>();
        int symm=sym;
        int symv=sym;

              for(int t=0; t<list.size(); t++){
                  if(sym-list.get(t)>=0) {
                      sym -= list.get(t);
                      list1.add(list.get(t));
                      list.remove(t);
                      t--;

                  if(sym==0){
                      for(int m=0; m<list.size(); m++){
                          if(symm-list.get(m)>=0){
                              symm-=list.get(m);
                              list2.add(list.get(m));
                              list.remove(m);
                              m--;
                          }
                      }
                  }
           }
        }
        int l1=0, l2=0;
           for(Integer l : list1){
               l1+=l;
           }
           for (Integer l : list2){
               l2+=l;
           }
           if(l1==l2 && list1.size()!=0){
//               for(Integer l : list1){
//                   System.out.print(l+" ");
//               }
//               System.out.println();
//               for(Integer l : list2){
//                   System.out.print(l+" ");
//               }
               System.out.print("Пояснение: можно нацепить блины  "+list1 +
                       " с одной стороны и блины "+list2+ " с другой, что в сумме даст "+symv*2+
                       ". ");
               if (list.size() != 0) {
               System.out.println("Оставшийся блин "+list+" не может быть нацеплен ни с одной из сторон без потери равновесия.");
               }
               else System.out.println();
               return false;
           }
           else {
               if(list1.size()!=0){
                   System.out.println("Пояснение: данный набор блинов невозможно нацепить без потери равновесия.");
               }
           }

  return true;
}

}
