import java.lang.reflect.Array;
import java.util.ArrayList;

public class HalfMass {
    public static void main (String args[]) throws Exception {
        //int mass[] = {2,3,14,9,4,5,2,15};
        int mass[] = {3,4,3,3,2};
        //int mass[] = {3,7,4,8,15,14,17,3,9,11,13,19,16};
        //int mass[] = {1,20};

        ArrayList<Integer> arraymass  = new ArrayList<>();

        for(int i = 0; i < mass.length; i++) {
            arraymass.add(mass[i]);
        }

        int maxSumm = massiv(arraymass);
        //showmass(arraymass);
        int allSumm = summass(arraymass);
        //System.out.println("START SUM: " + allSumm);
        //System.out.println("MAX SUM BALANCE: " + maxSumm);
        System.out.println(maxSumm);
        int kikNumber = allSumm - maxSumm;
        //System.out.println("DELETED ITEM (one or several): " + kikNumber);

    }

    //success division: return half sum
    //failure: return 0
    public static int search(ArrayList<Integer> mass, int halfSumm){
        //dividing array in left array and right
        ArrayList<Integer> leftmass  = new ArrayList<>();
        ArrayList<Integer> rightmass = new ArrayList<>();
        int leftMassSumm = 0;
        int rightMassSumm = 0;

        for(int i = 0; i < mass.size(); i ++ ) {
            leftMassSumm += mass.get(i);
            if(leftMassSumm <= halfSumm) {
                leftmass.add(mass.get(i));
            } else {
                leftMassSumm -= mass.get(i);
                rightMassSumm += mass.get(i);
                rightmass.add(mass.get(i));
            }
        }


        if(leftMassSumm == rightMassSumm) {//balance ready
            //System.out.println("Balance after first swap: " + leftMassSumm);
            return leftMassSumm;
        } else {
            //swap items betweeen arrays
            int halfSummMass = tryRavnoves(leftmass, rightmass);
            if(( halfSummMass != 0)&&(halfSummMass == rightMassSumm)&&(halfSummMass == leftMassSumm)) {
                //swap, sums coincide, return half sum
                    //System.out.println("Balance after swaps");
                    return halfSummMass;
            } else {//otherwise
                //System.out.println("No balance");
                return 0;
            }
        }
    }

    //try to balance
    public static int tryRavnoves(ArrayList<Integer> leftElements, ArrayList<Integer> rightElements){
        //System.out.print("Left Array: "); showmass(leftElements);
        //System.out.print("Right Array: "); showmass(rightElements);

        int n = summass(rightElements) - summass(leftElements);
        int leftToRight = 0;
        int rightToLeft = 0;
        for(int i = 0; i < leftElements.size(); i++ ) {
            for (int j = 0; j < rightElements.size(); j++) {
                if(leftElements.get(i) == (rightElements.get(j) - n)) {
                    //find items for balance
                    leftToRight = leftElements.get(i);
                    rightToLeft = rightElements.get(j);
                    leftElements.remove(i);
                    rightElements.remove(j);
                    leftElements.add(rightToLeft);
                    rightElements.add(leftToRight);//if items found, swap once
                    return summass(leftElements);//return half sum
                }
            }
        }
        return 0;//otherwise return 0
    }

    //show array on console
    public static void showmass(ArrayList<Integer> arraymass) {
        for(int i = 0; i < arraymass.size(); i++) {
            System.out.print( arraymass.get(i) + " ");
        }
        System.out.println();
    }

    //sum array items
    public static int summass(ArrayList<Integer> arraymass) {
        int summ = 0;
        for(int i = 0; i < arraymass.size(); i++) {
            summ += arraymass.get(i);
        }
        return summ;
    }


    public static int massiv(ArrayList<Integer> arraymass) throws Exception {

        int summ = 0;
        //sum up
        if((arraymass.size() > 1000)||(arraymass.size() < 1)) {
            throw new Exception();//Number of items [1,1000], otherwise error!
        }
        for(int i = 0; i < arraymass.size(); i++) {
            if((arraymass.get(i) >= 21)||(arraymass.get(i) <= 0)) {
                throw new Exception();//Item in [1,20], otherwise error!
            }
            summ += arraymass.get(i);
            if(summ > 10000) {
                throw new Exception();//Sum all items in [1,10000], otherwise error!
            }
        }

        int halfSumm = summ/2;
        int maxAnswer = 0;

        int memory = 0;
        for(int i = 0; i <= 21; i++) {
            if(memory != 0) {
                arraymass.add(memory);
                memory = 0;
            }
            for(int j = 0; j < arraymass.size(); j++) {
                if(arraymass.get(j) == i) {
                    arraymass.remove(j);
                    memory = i;
                    break;
                }
            }
            //System.out.print("Array without some number: ");
            //showmass(arraymass);//Array without 0,1,.....20
            halfSumm = summass(arraymass)/2;
            //System.out.println("Half sum " + halfSumm);

            int answer = search(arraymass, halfSumm);//success division: return half sum //failure: return 0

            if(answer > maxAnswer) {
                maxAnswer = answer;
            }
            //System.out.println("Max half sum (answer): " + maxAnswer);
            //System.out.println("-------------------------------");
        }

        return maxAnswer*2;
    }

}
